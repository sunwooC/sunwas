package cho.sunwoo.net.http;

import java.util.Map;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpRequest {
	private static Logger logger = LoggerFactory.getLogger(HttpRequest.class);
	private String method;
	private String url;
	private String version;
	private HttpHeaders headers = new HttpHeaders();	
	private HttpParameters parameters = new HttpParameters();	
	private String body;

	public HttpRequest(String method, String url, String version, String body,Map<String, String> headers,Map<String, String> parameters) {
		this.method = method;
		this.url = url;
		this.version = version;
		this.body = body;
		this.headers.setPrams(headers);
		this.parameters.setPrams(parameters);
	}

	public String getUrl() {
		return url;
	}
	public String getHost() {
		return headers.getHost();
	}
	public String getBody() {
		return body;
	}
	public String getVersion() {
		return version;
	}
	public String getHeader(String key) {
		return headers.getHeader(key);
	}

	public String getParameter(String key) {
		return parameters.getParameter(key);
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\\n------------------------------------------------\n");
		sb.append("method : ").append(this.method).append("\n");
		sb.append("url : ").append(this.url).append("\n");
		sb.append("version : ").append(this.version).append("\n");
		sb.append("headers : ").append(this.headers).append("\n");
		sb.append("parameters : ").append(this.parameters.toString()).append("\n");
		sb.append("body : ").append(this.body).append("\n");
		sb.append("------------------------------------------------");
		return sb.toString();
	}
}
