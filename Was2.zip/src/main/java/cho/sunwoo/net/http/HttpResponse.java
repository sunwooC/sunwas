package cho.sunwoo.net.http;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cho.sunwoo.was.config.ServerConfig;

public class HttpResponse {
    private static Logger logger = LoggerFactory.getLogger(HttpResponse.class);
    private HttpRequest req;
    private OutputStream output;
    private Writer out;
    private String version;
    private String responseCode;
    private String contentType;
    private int length;
    private ServerConfig config;
    public HttpResponse(OutputStream output) {
        this.output = output;
    }
    public void setReq(HttpRequest req) {
    	this.req = req;
    }
    public void setConfig(ServerConfig config) {
    	this.config = config;
    }
    public Writer getWriter() {
        if(this.out == null) {
            this.out = new OutputStreamWriter(this.output);
        }
        return this.out;
    }
    public void  sendHeader() throws IOException {
        Writer writer = this.getWriter();
        if (this.version.startsWith("HTTP/")) {
            writer.write(this.version + " " + this.responseCode + "\r\n");
            Date now = new Date();
            writer.write("Date: " + now + "\r\n");
            writer.write("Server: MyHTTP 2.0\r\n");
            if(length != 0) {
            	writer.write("Content-length: " + this.length + "\r\n");
            }
            writer.write("Content-type: " + this.contentType + "\r\n\r\n");
        }
    }
    
    public void sendBody(byte[] data) throws IOException {
        try {
            output.write(data);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            if (output != null) {
                output.flush();
            }
        }
    }
    
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public void sendResponse(HttpStatusCode stateCode, File file) throws IOException {
		byte[] data = null;
		if (file == null) {
			sendErrorResponse(HttpStatusCode.NOT_FOUND);
			return;
		}else {
			data = Files.readAllBytes(file.toPath());	
		}
        setVersion(req.getVersion());
		setResponseCode(stateCode.getCode() +" " + stateCode.getDesc());
        setContentType("text/html; charset=utf-8");
        setLength(data.length);
        sendHeader();
        getWriter().flush();
        sendBody(data);
        logger.info(toString());
	}
	public void sendErrorResponse(HttpStatusCode stateCode) throws IOException {
		File file = new File(config.getRootPath() + config.getDocumentRoot() + config.getErrorDocument().get(stateCode.getCode()+""));
		
		byte[] data = null;
		if (file == null) {
			data = "Page found page".getBytes();
		}else {
			data = Files.readAllBytes(file.toPath());	
		}
        setVersion(req.getVersion());
		setResponseCode(stateCode.getCode() +" " + stateCode.getDesc());
        setContentType("text/html; charset=utf-8");
        setLength(data.length);
        sendHeader();
        getWriter().flush();
        sendBody(data);
        logger.info(toString());
	}
    @Override
    public String toString() {
        return "Response: {" +
                "version: " + this.version + ", " +
                "responseCode: " + this.responseCode + ", " +
                "contentType: " + this.contentType +
            "}";
    }
}
