package cho.sunwoo.net.http;

import java.util.HashMap;
import java.util.Map;

public class HttpParameters {
	private Map<String, String> params = new HashMap<String, String>();
	public void setPrams(Map<String, String> params) {
		this.params = params;
	}
	public String getParameter(String key) {
		return params.get(key);
	}
	@Override
	public String toString() {
		return params.toString();
	}
}
