package cho.sunwoo.net.http;

import java.util.HashMap;
import java.util.Map;

public class HttpHeaders {
	private String host = "";
	private String port = "";
	private String method;
	private String accessFile;
	private String version = "HTTP/1.1";

	private Map<String, String> params = new HashMap<String, String>();

	public void setPrams(Map<String, String> params) {
		this.params = params;
		String host = this.params.get("Host");
		if(host != null && !"".equals(host)) {
			setHostData(host);
		}
	}

	public void setHostData(String hostInfo) {
		String split[] = hostInfo.split(":");
		host = hostInfo;
		if (split.length > 1) {
			host = split[0];
			port = split[1];
		}
	}

	public String getHost() {
		return host;
	}

	public String getPort() {
		return port;
	}
	public String getHeader(String key) {
		return params.get(key);
	}
	@Override
	public String toString() {
		return params.toString();
	}
}
