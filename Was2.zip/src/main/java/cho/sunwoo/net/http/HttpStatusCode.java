package cho.sunwoo.net.http;

public enum HttpStatusCode {
	OK(200, "OK"),
	FORBIDDEN(403, "Forbidden"),
    NOT_FOUND(404, "Not Found"),
    INTERNAL_SERVER_ERROR(500, "Internal Server Error");
	private int code;
    private String desc;
    private String text;

    HttpStatusCode(int code, String desc) {
        this.code = code;
        this.desc = desc;
        this.text = Integer.toString(code);
    }
    public int getCode() {
        return code;
    }

    public String asText() {
        return text;
    }

    public String getDesc() {
        return desc;
    }

    
}
