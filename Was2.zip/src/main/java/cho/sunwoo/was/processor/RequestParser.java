package cho.sunwoo.was.processor;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.LoggerFactory;

import cho.sunwoo.net.http.HttpRequest;

public class RequestParser {
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(RequestParser.class);
	public static final byte CR = '\r';
	public static final byte LF = '\n';

	private InputStream input = null;

	public RequestParser(InputStream input) {
		this.input = input;
	}

	public void getHeaderParser(InputStream input, Map<String, String> header) throws IOException {
		StringBuffer sb = new StringBuffer();

		int oneInt = -1;
		byte oldByte = (byte) -1;

		while (-1 != (oneInt = input.read())) {
			byte thisByte = (byte) oneInt;
			if (thisByte == RequestParser.LF && oldByte == RequestParser.CR) {

				String oneLine = sb.substring(0, sb.length() - 1);
				int idx = oneLine.indexOf(":");
				if (idx == -1) {
					// 헤더가 끝났다.
					break;
				}
				String key = oneLine.substring(0, idx).trim();
				String value = oneLine.substring(idx + 1).trim();
				header.put(key, value);
				sb.setLength(0);
			}
			sb.append((char) thisByte);
			oldByte = (byte) oneInt;
		}
	}

	public String getParamParser(String url, Map<String, String> parameters) {
		String[] tokens = url.split("\\?");
		if (tokens.length > 1) {
			url = tokens[0];
			String[] params = tokens[1].split("&");
			for (String param : params) {
				String[] keyValue = param.split("=");
				parameters.put(keyValue[0], keyValue[1]);
			}
		}
		return url;
	}

	public String getBodyParser(InputStream input, int contentLength) throws IOException {
		StringBuffer sb = new StringBuffer();
		int oneInt = -1;
		int bodyRead = 0;

		while (-1 != (oneInt = input.read())) {
			byte thisByte = (byte) oneInt;
			bodyRead++;
			sb.append((char) thisByte);
			if (bodyRead >= contentLength) {
				break;
			}
		}

		return sb.toString();
	}

	public String getFirstLine(InputStream input) throws IOException {
		StringBuffer sb = new StringBuffer();

		int oneInt = -1;
		byte oldByte = (byte) -1;

		while (-1 != (oneInt = input.read())) {
			byte thisByte = (byte) oneInt;
			if (thisByte == RequestParser.LF && oldByte == RequestParser.CR) {
				break;
			}
			sb.append((char) thisByte);
			oldByte = (byte) oneInt;
		}
		return sb.toString().trim();

	}

	public HttpRequest Parser() throws IOException {

		// BufferedReader br = new BufferedReader(new InputStreamReader(input,
		// "UTF-8"));
		String readLine;

		HttpRequest req = null;
		int status = 0;
		String method = "GET";
		String url = "/";
		String version = "HTTP/1.1";
		String body = "";
		Map<String, String> header = new HashMap();
		Map<String, String> parameters = new HashMap();

		String line = getFirstLine(input);
		final String[] fistLine = line.split(" ");
		method = fistLine[0];
		url = fistLine[1];
		version = fistLine[2];

		getHeaderParser(input, header);
		url = getParamParser(url, parameters);

		String contentLength = header.get("Content-Length");
		if (contentLength != null) {
			int length = Integer.parseInt(contentLength);
			body = getBodyParser(input, length);
		}

		req = new HttpRequest(method, url, version, body.toString(), header, parameters);
		logger.info("{}", req.toString());

		return req;
	}

}
