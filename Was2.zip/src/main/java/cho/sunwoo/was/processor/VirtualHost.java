package cho.sunwoo.was.processor;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

import org.slf4j.LoggerFactory;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpResponse;
import cho.sunwoo.net.http.HttpStatusCode;
import cho.sunwoo.was.config.ServerConfig;

public class VirtualHost {
	private HttpRequest req;
	private HttpResponse res;
	private OutputStream output;
	private ServerConfig config;
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(VirtualHost.class);

	public VirtualHost(HttpRequest req, OutputStream output, ServerConfig config) {
		this.req = req;
		this.output = output;
		this.config = config;
		res = new HttpResponse(output);
		res.setReq(req);
		res.setConfig(config);
	}

	public void exec() throws IOException {
		String filePath = req.getUrl();
		if( "/".equals(filePath) ) {
			filePath = config.getIndexDocument();
		}
		
		// 우선 순위
		// 1. 파일이 exe면 --403
		// 2. 정적 컨텐츠인데 --root_path 밖이면 403
		// 3. 정적 컨텐츠 조회
		// 4. 내부서블릿
		// 5. 외부서블릿
		// 6. 매핑 외부서블릿
		// 7 다 아니면 404
		// 8 오류 발생시 500

		
		// 1. 파일이 exe면 --403
		if (isFileExtBlock(filePath)) {
			res.sendErrorResponse(HttpStatusCode.FORBIDDEN);
			return;
		}
		File file = new File(config.getRootPath() + config.getDocumentRoot() + filePath);
		if(file.exists()) {
			String realFileFullPath = file.getCanonicalPath();
			// 2. 정적 컨텐츠인데 --root_path 밖이면 403
			if (!isResourcePath(realFileFullPath)) {
				res.sendErrorResponse(HttpStatusCode.FORBIDDEN);
				return;
			}
			res.sendResponse(HttpStatusCode.OK,file);
			return;
		}
		
		
		// 3. 내부서블릿
		if (isInServlet(filePath)) {
			return;
			
		}
		// 4. 외부서블릿
		if (isOutServlet(filePath)) {
			return;
		}

		// 5. 매핑 외부서블릿
		if (isMapping(filePath)) {
			return;
			
		}
		// 6. 정적 컨텐츠 조회
		if (isMapping(filePath)) {
			return;
		}

		// 7 다 아니면 404
		res.sendErrorResponse(HttpStatusCode.NOT_FOUND);


	}

	public boolean isFileExtBlock(String fileName) throws ArrayIndexOutOfBoundsException {
		if (fileName == null) {
			return false;
		}
		int lastIndexOf = fileName.lastIndexOf(".");
		if (lastIndexOf > -1) {
			String fileExt = fileName.substring(lastIndexOf + 1);
			logger.info("file ext : {}",fileExt);
			return Arrays.asList(config.getBlockedExt().split(",")).contains(fileExt);
		}
		return false;
	}

	public boolean isResourcePath(String realFileFullPath) throws IOException {
		String basePath = config.getRootPath() + config.getDocumentRoot();
		String osBasePath= basePath.replaceAll("\\\\", "/");
		//윈도우와 리눅스 디렉토리 구분자 문제로 치환해서 처리
		String filePath = realFileFullPath.replaceAll("\\\\", "/");
		System.out.println(filePath.startsWith(osBasePath));
		logger.info("filePath : {}",filePath);
		logger.info("osBasePath : {}",osBasePath);
		return filePath.startsWith(osBasePath);
	}
	public boolean isMapping(String fileName) {
		return false;
	}


	public boolean isInServlet(String fileName) {
		return false;
	}
	public boolean isOutServlet(String fileName) {
		return false;
	}

}
