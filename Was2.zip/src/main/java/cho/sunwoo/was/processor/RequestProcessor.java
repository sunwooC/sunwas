package cho.sunwoo.was.processor;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.util.Date;

import org.slf4j.LoggerFactory;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.was.config.Config;
import cho.sunwoo.was.config.ServerConfig;

public class RequestProcessor implements Runnable {
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(RequestProcessor.class);
    private File rootDirectory;
    private String indexFileName = "index.html";
    private Socket connection;
    private String ROOT_PATH;

    public RequestProcessor(Socket connection) {
    	this.connection = connection;
    }

    @Override
    public void run() {
    	try {
    		ServerConfig serverConfig = null;
    		File path = new File("");
    		ROOT_PATH = path.getAbsolutePath();
    		logger.info(ROOT_PATH);
			InputStream input = connection.getInputStream();
			OutputStream output = this.connection.getOutputStream();
			Writer out = new OutputStreamWriter(output);
			
	 		RequestParser parser = new RequestParser(input);
	 		HttpRequest req = parser.Parser();
	 		String host = req.getHost();
	 		if(!"".equals(host)) {
	 			serverConfig = Config.getInstance().getServierInfo(host);
	 			if (serverConfig == null) {
	 				serverConfig = Config.getInstance().getDefaultServierInfo();
	 			}
	 			serverConfig.setRootPath(ROOT_PATH);
	 			VirtualHost virtualHost = new VirtualHost(req,output,serverConfig);
	 			virtualHost.exec();
	 		}
		} catch (IOException e) {
			logger.error("",e);
		} catch (RuntimeException e) {
			logger.error("",e);
		} catch (Exception e) {
			logger.error("",e);
		} finally {
			try {
				logger.info("connection close");
				connection.close();
			} catch (IOException e) {
				logger.error("",e);
			}
		}
    }
}