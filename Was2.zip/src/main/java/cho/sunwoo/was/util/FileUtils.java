package cho.sunwoo.was.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;




public class FileUtils {
	public static JSONObject getFileContent(String fileName) throws FileNotFoundException, IOException, ParseException  {
		ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        InputStream is = classLoader.getResourceAsStream(fileName);
        
        
        JSONParser parser = new JSONParser();
        Object obj = parser.parse(new InputStreamReader(is));
        JSONObject jsonObject = (JSONObject) obj;
        return  (JSONObject) obj;
        
        /*
        BufferedReader rd = new BufferedReader(new InputStreamReader(is));
        String line;
        StringBuffer buffer = new StringBuffer(); 
        while((line = rd.readLine()) != null) {
        	buffer.append(line);
        	buffer.append('\r');
        }
        rd.close();
        JSONObject jObject = new JSONObject(buffer.toString());
        return jObject;
        */
    }
}
