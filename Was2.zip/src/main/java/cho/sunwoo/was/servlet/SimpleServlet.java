package cho.sunwoo.was.servlet;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpResponse;

public interface SimpleServlet {
	void service(HttpRequest req, HttpResponse res) throws Exception;
}
