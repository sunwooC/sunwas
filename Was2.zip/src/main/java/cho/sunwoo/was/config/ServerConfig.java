package cho.sunwoo.was.config;

import java.util.Map;

public class ServerConfig {
	private String serverName;
	private String documentRoot;
	private String indexDocument;
	private Map<String, String> errorDocument;
	private String blockedExt;
	private String rootPath;

	public String getBlockedExt() {
		return blockedExt;
	}

	public void setBlockedExt(String blockedExt) {
		this.blockedExt = blockedExt;
	}

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getDocumentRoot() {
		return documentRoot;
	}

	public void setDocumentRoot(String documentRoot) {
		this.documentRoot = documentRoot;
	}

	public String getIndexDocument() {
		return indexDocument;
	}

	public void setIndexDocument(String indexDocument) {
		this.indexDocument = indexDocument;
	}

	public Map<String, String> getErrorDocument() {
		return errorDocument;
	}

	public void setErrorDocument(Map<String, String> errorDocument) {
		this.errorDocument = errorDocument;
	}

}
