package cho.sunwoo.was.config;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.LoggerFactory;

import cho.sunwoo.was.util.FileUtils;

public class Config {
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(Config.class);
	private JSONObject wasInfo = null;
	private Map<String, ServerConfig> serverInfo;
	private String defaultHost = "";

	private Config() throws Exception {
		wasInfo = FileUtils.getFileContent("application.json");
		serverInfo = new HashMap();
		JSONArray hosts = (JSONArray) wasInfo.get("VirtualHost");

		for (int i = 0; i < hosts.size(); i++) {
			JSONObject host = (JSONObject) hosts.get(i);
			String serverName = (String) host.get("ServerName");
			if(i == 0) {
				defaultHost = serverName;
			}
			String documentRoot = (String) host.get("DocumentRoot");
			String indexDocument = (String) host.get("IndexDocument");
			ServerConfig serverConfig = new ServerConfig();
			serverConfig.setServerName(serverName);
			serverConfig.setDocumentRoot(documentRoot);
			serverConfig.setIndexDocument(indexDocument);
			JSONObject errorObj = (JSONObject) host.get("ErrorDocument");
			// errorObj
			serverConfig.setErrorDocument((HashMap) errorObj);
			serverConfig.setBlockedExt(getBlockedExtension());;
			
			serverInfo.put(serverName, serverConfig);
		}

	}
	public ServerConfig getDefaultServierInfo() {
		return serverInfo.get(defaultHost);
	}
	public ServerConfig getServierInfo(String serverName) {
		return serverInfo.get(serverName);
	}
	public String getBlockedExtension() {
		return (String)wasInfo.get("blockedExtension");
	}
	
	public int getPort() {
		Long port = (Long) wasInfo.get("port");
		if (port == null) {
			port = 80L;
		}
		return (int) ((long) port);
	}

	private static class LazyHolder {
		public static final Config INSTANCE;
		static {
			try {
				INSTANCE = new Config();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				throw new RuntimeException("Exception creating Config instance.");
			}
		}
	}

	public static Config getInstance() {
		return LazyHolder.INSTANCE;
	}
}
