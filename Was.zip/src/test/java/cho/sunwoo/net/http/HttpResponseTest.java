package cho.sunwoo.net.http;

import static org.junit.Assert.*;

import org.junit.Test;

public class HttpResponseTest {
/*
	@Test
	public void testHttpResponse() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetReq() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetConfig() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWriter() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendBody() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVersion() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetVersion() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetResponseCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetResponseCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetContentType() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetContentType() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLength() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetLength() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendResponse() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendErrorResponse() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendServerResponse() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}
*/

}
