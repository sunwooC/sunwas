package cho.sunwoo.net.http;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class HttpHeadersTest {

	private HttpHeaders httpHeaders;
	@Before
	public void init() {
		httpHeaders = new HttpHeaders();
	}
	@Test
	public void testSetPrams() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("test", "testResult");
		httpHeaders.setPrams(params);
		String result = httpHeaders.getHeader("test");
		assertEquals("testResult", result); 
	}

	@Test
	public void testSetHostData() {
		httpHeaders.setHostData("hostId");
		String data = httpHeaders.getHost();
		assertEquals("hostId", data); 
	}

	@Test
	public void testGetHost() {
		httpHeaders.setHostData("hostId:80");
		String data = httpHeaders.getHost();
		assertEquals("hostId", data); 
	}

	@Test
	public void testGetPort() {
		httpHeaders.setHostData("hostId:80");
		String data = httpHeaders.getPort();
		assertEquals("80", data); 
	}

	@Test
	public void testGetHeader() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("test", "testResult");
		httpHeaders.setPrams(params);
		String result = httpHeaders.getHeader("test");
		assertEquals("testResult", result); 
	}
}
