package cho.sunwoo.net.http;

import static org.junit.Assert.*;

import org.junit.Test;

public class HttpRequestTest {
/*
	@Test
	public void testHttpRequest() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUrl() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetHost() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBody() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVersion() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetHeader() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetParameter() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}
*/
}
