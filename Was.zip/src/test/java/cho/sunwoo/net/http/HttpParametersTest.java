package cho.sunwoo.net.http;

import static org.junit.Assert.*;

import org.junit.Test;

public class HttpParametersTest {
/*
	@Test
	public void testSetPrams() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetParameter() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}
*/
}
