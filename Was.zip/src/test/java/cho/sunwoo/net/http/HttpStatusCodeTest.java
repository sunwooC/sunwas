package cho.sunwoo.net.http;

import static org.junit.Assert.*;

import org.junit.Test;

public class HttpStatusCodeTest {
/*
	@Test
	public void testHttpStatusCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testAsText() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDesc() {
		fail("Not yet implemented");
	}
*/

}
