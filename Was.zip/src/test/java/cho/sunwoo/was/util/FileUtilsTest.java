package cho.sunwoo.was.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class FileUtilsTest {
/*
	@Test
	public void testGetFileContent() {
		fail("Not yet implemented");
	}
*/
}
