package cho.sunwoo.was.config;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConfigTest {
/*
	@Test
	public void testGetDefaultServierInfo() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetServierInfo() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBlockedExtension() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPort() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetInstance() {
		fail("Not yet implemented");
	}
*/

}
