package cho.sunwoo.was.config;

import static org.junit.Assert.*;

import org.junit.Test;

public class ServerConfigTest {
/*
	@Test
	public void testGetBlockedExt() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetBlockedExt() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRootPath() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetRootPath() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetServerName() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetServerName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDocumentRoot() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetDocumentRoot() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetIndexDocument() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetIndexDocument() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetErrorDocument() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetErrorDocument() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetServeltMapping() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetServeltMappingt() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetExtJar() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetExtJar() {
		fail("Not yet implemented");
	}
*/
}
