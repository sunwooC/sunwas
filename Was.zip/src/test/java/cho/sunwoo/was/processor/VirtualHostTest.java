package cho.sunwoo.was.processor;

import static org.junit.Assert.*;

import org.junit.Test;

public class VirtualHostTest {
/*
	@Test
	public void testVirtualHost() {
		fail("Not yet implemented");
	}

	@Test
	public void testExec() {
		fail("Not yet implemented");
	}
*/
}
