package cho.sunwoo.was.processor;

import static org.junit.Assert.*;

import org.junit.Test;

public class BaseHostProcessTest {
/*
	@Test
	public void testBaseHostProcess() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsFileExtBlock() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsResourcePath() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetServlet() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetInServlet() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetOutServlet() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMaapingServlet() {
		fail("Not yet implemented");
	}
*/
}
