package ext1.service;
import java.io.Writer;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpResponse;
import cho.sunwoo.was.servlet.SimpleServlet;


public class ExtHello implements SimpleServlet{

	@Override
	public void service(HttpRequest req, HttpResponse res) throws Exception {
		Writer writer = res.getWriter();
		writer.write("ext.ervice.ExtHello, ");
		writer.write(req.getParameter("name"));
		
	}

}
