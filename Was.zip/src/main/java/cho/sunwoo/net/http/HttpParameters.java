package cho.sunwoo.net.http;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @FileName  : HttpParameters.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class HttpParameters {
	private Map<String, String> params = new HashMap<String, String>();

	/**
	 * @Method Name  : setPrams
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param params
	 */
	public void setPrams(Map<String, String> params) {
		this.params = params;
	}

	/**
	 * @Method Name  : getParameter
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param key
	 * @return
	 */
	public String getParameter(String key) {
		return Optional.ofNullable(params.get(key)).orElse("");
	}

	@Override
	public String toString() {
		return params.toString();
	}
}
