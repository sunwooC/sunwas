package cho.sunwoo.net.http;

import java.util.HashMap;
import java.util.Map;

/**
 * @FileName  : HttpHeaders.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */

public class HttpHeaders {	
	private String host = "";
	private String port = "";

	private Map<String, String> params = new HashMap<String, String>();

	/**
	 * @Method Name  : setPrams
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param params
	 */
	public void setPrams(Map<String, String> params) {
		this.params = params;
		String host = this.params.get("Host");
		if(host != null && !"".equals(host)) {
			setHostData(host);
		}
	}

	/**
	 * @Method Name  : setHostData
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param hostInfo
	 */
	public void setHostData(String hostInfo) {
		String split[] = hostInfo.split(":");
		host = hostInfo;
		if (split.length > 1) {
			host = split[0];
			port = split[1];
		}
	}

	/**
	 * @Method Name  : getHost
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @Method Name  : getPort
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getPort() {
		return port;
	}
	/**
	 * @Method Name  : getHeader
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param key
	 * @return
	 */
	public String getHeader(String key) {
		return params.get(key);
	}

	@Override
	public String toString() {
		return params.toString();
	}
}
