package cho.sunwoo.net.http;

import java.util.Map;

/**
 * @FileName  : HttpRequest.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class HttpRequest {
	private String method;
	private String url;
	private String version;
	private HttpHeaders headers = new HttpHeaders();	
	private HttpParameters parameters = new HttpParameters();	
	private String body;

	/**
	 * @param method
	 * @param url
	 * @param version
	 * @param body
	 * @param headers
	 * @param parameters
	 */
	public HttpRequest(String method, String url, String version, String body,Map<String, String> headers,Map<String, String> parameters) {
		this.method = method;
		this.url = url;
		this.version = version;
		this.body = body;
		this.headers.setPrams(headers);
		this.parameters.setPrams(parameters);
	}

	/**
	 * @Method Name  : getUrl
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @Method Name  : getHost
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getHost() {
		return headers.getHost();
	}
	/**
	 * @Method Name  : getBody
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getBody() {
		return body;
	}
	/**
	 * @Method Name  : getVersion
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getVersion() {
		return version;
	}
	/**
	 * @Method Name  : getHeader
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param key
	 * @return
	 */
	public String getHeader(String key) {
		return headers.getHeader(key);
	}

	/**
	 * @Method Name  : getParameter
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param key
	 * @return
	 */
	public String getParameter(String key) {
		return parameters.getParameter(key);
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\\n------------------------------------------------\n");
		sb.append("method : ").append(this.method).append("\n");
		sb.append("url : ").append(this.url).append("\n");
		sb.append("version : ").append(this.version).append("\n");
		sb.append("headers : ").append(this.headers).append("\n");
		sb.append("parameters : ").append(this.parameters.toString()).append("\n");
		sb.append("body : ").append(this.body).append("\n");
		sb.append("------------------------------------------------");
		return sb.toString();
	}
}
