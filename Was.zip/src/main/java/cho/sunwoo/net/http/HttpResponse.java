package cho.sunwoo.net.http;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cho.sunwoo.was.config.ServerConfig;
import cho.sunwoo.was.servlet.SimpleServlet;

/**
 * @FileName  : HttpResponse.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class HttpResponse {
	private static Logger logger = LoggerFactory.getLogger(HttpResponse.class);
	private HttpRequest req;
	private OutputStream output;
	private Writer out;
	private String version;
	private String responseCode;
	private String contentType;
	private int length;
	private ServerConfig config;


	public HttpResponse(OutputStream output) {
		this.output = output;
	}

	/**
	 * @Method Name  : setReq
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param req
	 */
	/**
	 * @Method Name  : setReq
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param req
	 */
	public void setReq(HttpRequest req) {
		this.req = req;
	}

	/**
	 * @Method Name  : setConfig
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param config
	 */
	public void setConfig(ServerConfig config) {
		this.config = config;
	}

	/**
	 * @Method Name  : getWriter
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public Writer getWriter() {
		if (this.out == null) {
			this.out = new OutputStreamWriter(this.output);
		}
		return this.out;
	}

	/**
	 * @Method Name  : sendHeader
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @throws IOException
	 */
	public void sendHeader() throws IOException {
		Writer writer = this.getWriter();
		if (this.version.startsWith("HTTP/")) {
			writer.write(this.version + " " + this.responseCode + "\r\n");
			Date now = new Date();
			writer.write("Date: " + now + "\r\n");
			writer.write("Server: MyHTTP 2.0\r\n");
			if (length != 0) {
				writer.write("Content-length: " + this.length + "\r\n");
			}
			writer.write("Content-type: " + this.contentType + "\r\n\r\n");
		}
	}

	/**
	 * @Method Name  : sendBody
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param data
	 * @throws IOException
	 */
	public void sendBody(byte[] data) throws IOException {
		try {
			output.write(data);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			if (output != null) {
				output.flush();
			}
		}
	}

	/**
	 * @Method Name  : getVersion
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @Method Name  : setVersion
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param version
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @Method Name  : getResponseCode
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * @Method Name  : setResponseCode
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param responseCode
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @Method Name  : getContentType
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * @Method Name  : setContentType
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param contentType
	 */
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	/**
	 * @Method Name  : getLength
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public int getLength() {
		return length;
	}

	/**
	 * @Method Name  : setLength
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param length
	 */
	public void setLength(int length) {
		this.length = length;
	}

	/**
	 * @Method Name  : sendResponse
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param stateCode
	 * @param file
	 * @throws IOException
	 */
	public void sendResponse(HttpStatusCode stateCode, File file) throws IOException {
		byte[] data = null;
		if (file == null) {
			sendErrorResponse(HttpStatusCode.NOT_FOUND);
			return;
		} else {
			data = Files.readAllBytes(file.toPath());
		}
		setVersion(req.getVersion());
		setResponseCode(stateCode.asText());
		setContentType("text/html; charset=utf-8");
		setLength(data.length);
		sendHeader();
		getWriter().flush();
		sendBody(data);
		logger.info(toString());
	}

	/**
	 * @Method Name  : sendErrorResponse
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param stateCode
	 * @throws IOException
	 */
	public void sendErrorResponse(HttpStatusCode stateCode) throws IOException {
		String errorPage = config.getErrorDocument(stateCode.getCode());
		File file = null;
		if (!"".equals(errorPage)) {
			file = new File(config.getRootPath() + config.getDocumentRoot() + errorPage);
		}
		byte[] data = null;
		if (!file.isFile()) {
			data = "Page found page".getBytes();
		} else {
			data = Files.readAllBytes(file.toPath());
		}
		setVersion(req.getVersion());
		setResponseCode(stateCode.asText());
		setContentType("text/html; charset=utf-8");
		setLength(data.length);
		sendHeader();
		getWriter().flush();
		sendBody(data);
		logger.info(toString());
	}

	/**
	 * @Method Name  : sendServerResponse
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param servlet
	 * @throws Exception
	 */
	public void sendServerResponse(SimpleServlet servlet) throws Exception {
		setVersion(req.getVersion());
		setResponseCode(HttpStatusCode.OK.asText());
		setContentType("text/html; charset=utf-8");
		sendHeader();
		servlet.service(req, this);
		getWriter().flush();
	}

	@Override
	public String toString() {
		return "Response: {" + "version: " + this.version + ", " + "responseCode: " + this.responseCode + ", "
				+ "contentType: " + this.contentType + "}";
	}
}
