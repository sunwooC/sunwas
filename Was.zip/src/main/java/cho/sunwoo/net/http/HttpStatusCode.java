package cho.sunwoo.net.http;

/**
 * @FileName  : HttpStatusCode.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public enum HttpStatusCode {
	OK("200", "OK"),
	FORBIDDEN("403", "Forbidden"),
    NOT_FOUND("404", "Not Found"),
    INTERNAL_SERVER_ERROR("500", "Internal Server Error");
	private String code;
    private String desc;
    private String text;

    HttpStatusCode(String code, String desc) {
        this.code = code;
        this.desc = desc;
        this.text = code + " " + desc;
    }
    /**
     * @Method Name  : getCode
     * @작성일   : 2021. 9. 1.
     * @작성자   : User1
     * @변경이력  :
     * @Method 설명 :
     * @return
     */
    public String getCode() {
        return code;
    }

    /**
     * @Method Name  : asText
     * @작성일   : 2021. 9. 1.
     * @작성자   : User1
     * @변경이력  :
     * @Method 설명 :
     * @return
     */
    public String asText() {
        return text;
    }

    /**
     * @Method Name  : getDesc
     * @작성일   : 2021. 9. 1.
     * @작성자   : User1
     * @변경이력  :
     * @Method 설명 :
     * @return
     */
    public String getDesc() {
        return desc;
    }

    
}
