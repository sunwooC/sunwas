package cho.sunwoo.was;


import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import cho.sunwoo.was.config.Config;
import cho.sunwoo.was.processor.RequestProcessor;

/**
 * @FileName  : HttpServer.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class HttpServer {
    private static final Logger logger = Logger.getLogger(HttpServer.class.getCanonicalName());
    private static final int NUM_THREADS = 50;
    private static final String INDEX_FILE = "index.html";
    //private final File rootDirectory;
    private final int port;

    public HttpServer(int port) {
        this.port = port;
    }

    /**
     * @Method Name  : start
     * @작성일   : 2021. 9. 1.
     * @작성자   : User1
     * @변경이력  :
     * @Method 설명 :
     * @throws IOException
     */
    public void start() throws IOException {
        ExecutorService pool = Executors.newFixedThreadPool(NUM_THREADS);
        try (ServerSocket server = new ServerSocket(port)) {
            logger.info("Accepting connections on port " + server.getLocalPort());
            while (true) {
                try {
                    Socket request = server.accept();
                    Runnable r = new RequestProcessor(request);
                    pool.submit(r);
                } catch (IOException ex) {
                    logger.log(Level.WARNING, "Error accepting connection", ex);
                }
            }
        }
    }

    /**
     * @Method Name  : main
     * @작성일   : 2021. 9. 1.
     * @작성자   : User1
     * @변경이력  :
     * @Method 설명 :
     * @param args
     */
    public static void main(String[] args) {
        // get the Document root
        File path = new File("");
        String ROOT_PATH = path.getAbsolutePath();
        Config config = Config.getInstance();
        // set the port to listen on
        int port = config.getPort();
        try {
            HttpServer webserver = new HttpServer(port);
            webserver.start();
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Server could not start", ex);
        }
    }
}