package cho.sunwoo.was.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.LoggerFactory;

import cho.sunwoo.was.util.FileUtils;

/**
 * @FileName  : Config.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class Config {
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(Config.class);
	private JSONObject wasInfo = null;
	private Map<String, ServerConfig> serverInfo;
	private String defaultHost = "";

	private Config() throws Exception {
		wasInfo = FileUtils.getFileContent("application.json");
		serverInfo = new HashMap();
		JSONArray hosts = (JSONArray) wasInfo.get("VirtualHost");

		for (int i = 0; i < hosts.size(); i++) {
			JSONObject host = (JSONObject) hosts.get(i);
			String serverName = (String) host.get("ServerName");
			if (i == 0) {
				defaultHost = serverName;
			}
			String documentRoot = (String) host.get("DocumentRoot");
			String indexDocument = (String) host.get("IndexDocument");
			String extJar = (String) host.get("extJar");

			ServerConfig serverConfig = new ServerConfig();
			serverConfig.setServerName(serverName);
			serverConfig.setDocumentRoot(documentRoot);
			serverConfig.setIndexDocument(indexDocument);
			JSONObject errorObj = (JSONObject) host.get("ErrorDocument");
			// errorObj
			serverConfig.setErrorDocument((HashMap) errorObj);

			JSONObject serveltMapping = (JSONObject) host.get("ServletMapping");
			serverConfig.setServeltMappingt(serveltMapping);

			serverConfig.setBlockedExt(getBlockedExtension());
			serverConfig.setExtJar(extJar);

			serverInfo.put(serverName, serverConfig);
		}

	}
	/**
	 * @Method Name  : getDefaultServierInfo
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public ServerConfig getDefaultServierInfo() {
		return serverInfo.get(defaultHost);
	}

	/**
	 * @Method Name  : getServierInfo
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param serverName
	 * @return
	 */
	public ServerConfig getServierInfo(String serverName) {
		return Optional.ofNullable(serverInfo.get(serverName)).orElse(getDefaultServierInfo());
	}
	/**
	 * @Method Name  : getBlockedExtension
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getBlockedExtension() {
		if (wasInfo == null)
			return "";
		return (String) Optional.ofNullable(wasInfo.get("blockedExtension")).orElse("");
	}
	/**
	 * @Method Name  : getPort
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public int getPort() {
		if (wasInfo == null) {
			return 80;
		}
		Long port = (Long) Optional.ofNullable(wasInfo.get("port")).orElse(80L);
		return (int) ((long) port);
	}
	
	private static class LazyHolder {
		public static final Config INSTANCE;
		static {
			try {
				INSTANCE = new Config();
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				throw new RuntimeException("Exception creating Config instance.");
			}
		}
	}
	/**
	 * @Method Name  : getInstance
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public static Config getInstance() {
		return LazyHolder.INSTANCE;
	}
}
