package cho.sunwoo.was.config;

import java.util.Map;
import java.util.Optional;

/**
 * @FileName  : ServerConfig.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class ServerConfig {
	private String serverName = "";
	private String documentRoot = "";
	private String indexDocument = "";
	private String blockedExt = "";
	private String rootPath = "";
	private Map<String, String> errorDocument;
	private Map<String, String> serveltMapping;
	private String extJar = "";

	/**
	 * @Method Name  : getBlockedExt
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getBlockedExt() {
		return blockedExt;
	}

	/**
	 * @Method Name  : setBlockedExt
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param blockedExt
	 */
	public void setBlockedExt(String blockedExt) {
		this.blockedExt = blockedExt;
	}

	/**
	 * @Method Name  : getRootPath
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getRootPath() {
		return rootPath;
	}

	/**
	 * @Method Name  : setRootPath
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param rootPath
	 */
	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	/**
	 * @Method Name  : getServerName
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getServerName() {
		return serverName;
	}

	/**
	 * @Method Name  : setServerName
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param serverName
	 */
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	/**
	 * @Method Name  : getDocumentRoot
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getDocumentRoot() {
		return documentRoot;
	}

	/**
	 * @Method Name  : setDocumentRoot
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param documentRoot
	 */
	public void setDocumentRoot(String documentRoot) {
		this.documentRoot = documentRoot;
	}

	/**
	 * @Method Name  : getIndexDocument
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getIndexDocument() {
		return indexDocument;
	}

	/**
	 * @Method Name  : setIndexDocument
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param indexDocument
	 */
	public void setIndexDocument(String indexDocument) {
		this.indexDocument = indexDocument;
	}

	/**
	 * @Method Name  : getErrorDocument
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param errorCode
	 * @return
	 */
	public String getErrorDocument(String errorCode) {
		if (errorDocument == null) {
			return "";
		}
		return Optional.ofNullable(errorDocument.get(errorCode)).orElse("");
	}

	/**
	 * @Method Name  : setErrorDocument
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param errorDocument
	 */
	public void setErrorDocument(Map<String, String> errorDocument) {
		this.errorDocument = errorDocument;
	}

	/**
	 * @Method Name  : getServeltMapping
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param errorCode
	 * @return
	 */
	public String getServeltMapping(String errorCode) {
		if (serveltMapping == null) {
			return "";
		}
		return Optional.ofNullable(serveltMapping.get(errorCode)).orElse("");
	}

	/**
	 * @Method Name  : setServeltMappingt
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param serveltMapping
	 */
	public void setServeltMappingt(Map<String, String> serveltMapping) {
		this.serveltMapping = serveltMapping;
	}

	/**
	 * @Method Name  : getExtJar
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @return
	 */
	public String getExtJar() {
		return extJar;
	}

	/**
	 * @Method Name  : setExtJar
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param extJar
	 */
	public void setExtJar(String extJar) {
		if (extJar != null) {
			this.extJar = extJar;
		}
	}

}
