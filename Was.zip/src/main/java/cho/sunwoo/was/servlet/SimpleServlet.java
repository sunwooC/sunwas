package cho.sunwoo.was.servlet;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpResponse;

/**
 * @FileName  : SimpleServlet.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public interface SimpleServlet {
	void service(HttpRequest req, HttpResponse res) throws Exception;
}
