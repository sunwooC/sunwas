package cho.sunwoo.was.processor;

import java.io.File;
import java.io.OutputStream;

import org.slf4j.LoggerFactory;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpStatusCode;
import cho.sunwoo.was.config.ServerConfig;
import cho.sunwoo.was.servlet.SimpleServlet;

/**
 * @FileName  : VirtualHost.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class VirtualHost extends BaseHostProcess{
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(VirtualHost.class);

	public VirtualHost(HttpRequest req, OutputStream output, ServerConfig config) {
		super(req,output,config);
	}

	/**
	 * @Method Name  : exec
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @throws Exception
	 */
	public void exec() throws Exception {
		String filePath = req.getUrl();
		if( "/".equals(filePath) ) {
			filePath = config.getIndexDocument();
		}
		
		// 우선 순위
		// 1. 파일이 exe면 --403
		// 2. 정적 컨텐츠인데 --root_path 밖이면 403
		// 3. 정적 컨텐츠 조회
		// 4. 내부서블릿
		// 5. 외부서블릿
		// 6. 매핑 외부서블릿
		// 7 다 아니면 404
		// 8 오류 발생시 500

		
		// 1. 파일이 exe면 --403
		if (isFileExtBlock(filePath)) {
			res.sendErrorResponse(HttpStatusCode.FORBIDDEN);
			return;
		}
		File file = new File(config.getRootPath() + config.getDocumentRoot() + filePath);
		if(file.exists()) {
			String realFileFullPath = file.getCanonicalPath();
			// 2. 정적 컨텐츠인데 --root_path 밖이면 403
			if (!isResourcePath(realFileFullPath)) {
				res.sendErrorResponse(HttpStatusCode.FORBIDDEN);
				return;
			}
			// 3. 정적 컨텐츠 조회
			res.sendResponse(HttpStatusCode.OK,file);
			return;
		}
		
		// 4. 외부서블릿
		// 5. 매핑 외부서블릿
		// 6. 정적 컨텐츠 조회
		SimpleServlet servlet = getServlet(filePath);
		if(servlet != null) {
			res.sendServerResponse(servlet);
			return;
		}
		// 7 다 아니면 404
		res.sendErrorResponse(HttpStatusCode.NOT_FOUND);
	}
}
