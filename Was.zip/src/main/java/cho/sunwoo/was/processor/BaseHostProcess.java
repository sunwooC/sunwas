package cho.sunwoo.was.processor;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpResponse;
import cho.sunwoo.was.config.ServerConfig;
import cho.sunwoo.was.servlet.SimpleServlet;

/**
 * @FileName  : BaseHostProcess.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class BaseHostProcess {
	protected HttpRequest req;
	protected HttpResponse res;
	protected OutputStream output;
	protected ServerConfig config;
	private static Logger logger = LoggerFactory.getLogger(BaseHostProcess.class);
	
	public BaseHostProcess(HttpRequest req,OutputStream output,ServerConfig config) {
		this.req = req;
		this.output = output;
		this.config =  config;
		res = new HttpResponse(output);
		res.setReq(req);
		res.setConfig(config);
	}
	
	/**
	 * @Method Name  : isFileExtBlock
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param fileName
	 * @return
	 * @throws ArrayIndexOutOfBoundsException
	 */
	public boolean isFileExtBlock(final String fileName) throws ArrayIndexOutOfBoundsException {
		if (fileName == null) {
			return false;
		}
		int lastIndexOf = fileName.lastIndexOf(".");
		if (lastIndexOf > -1) {
			String fileExt = fileName.substring(lastIndexOf + 1);
			logger.info("file ext : {}",fileExt);
			return Arrays.asList(config.getBlockedExt().split(",")).contains(fileExt);
		}
		return false;
	}
	
	/**
	 * @Method Name  : isResourcePath
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param realFileFullPath
	 * @return
	 * @throws IOException
	 */
	public boolean isResourcePath(final String realFileFullPath) throws IOException {
		String basePath = config.getRootPath() + config.getDocumentRoot();
		String osBasePath= basePath.replaceAll("\\\\", "/");
		//윈도우와 리눅스 디렉토리 구분자 문제로 치환해서 처리
		String filePath = realFileFullPath.replaceAll("\\\\", "/");
		System.out.println(filePath.startsWith(osBasePath));
		logger.info("filePath : {}",filePath);
		logger.info("osBasePath : {}",osBasePath);
		return filePath.startsWith(osBasePath);
	}
	
	/**
	 * @Method Name  : getServlet
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param fileName
	 * @return
	 */
	public SimpleServlet getServlet(final String fileName) {
		SimpleServlet servlet = null;
		servlet = getInServlet(fileName);
		if(servlet != null) {
			return servlet;
		}
		servlet =  getOutServlet(fileName);
		if(servlet != null) {
			return servlet;
		}
		servlet = getMaapingServlet(fileName);
		return servlet;
	}
	
	/**
	 * @Method Name  : getInServlet
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param fileName
	 * @return
	 */
	public SimpleServlet getInServlet(final String fileName) {
		SimpleServlet servlet = null;
		String classFullPath = fileName.replace("/", "");
		try {
			Class<SimpleServlet> forName = (Class<SimpleServlet>) Class.forName(classFullPath);
			servlet = forName.newInstance();
		} catch (InstantiationException e) {
			//e.printStackTrace();
		} catch (IllegalAccessException e) {
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		}
		return servlet;
	}
	
	/**
	 * @Method Name  : getOutServlet
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param fileName
	 * @return
	 */
	public SimpleServlet getOutServlet(final String fileName) {
		SimpleServlet servlet = null;
		if("".equals(config.getExtJar())) {
			return servlet;
		}
		String jarPath = config.getRootPath() + config.getDocumentRoot() + config.getExtJar();
		File file = new File(jarPath);
		if(!file.isFile()) {
			return servlet;
		}
		String classFullPath = fileName.replace("/", "");
		URL url;
		try {
			url = new URL(null,"file:" + file.getCanonicalPath());
		logger.debug(file.getCanonicalPath());
		URL[] urls = new URL[]{ url};
		URLClassLoader classLoader = new URLClassLoader(urls);
		Class<SimpleServlet> forName = (Class<SimpleServlet>) classLoader.loadClass(classFullPath);
			servlet = forName.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			//e.printStackTrace();
		} catch (IOException e) {
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
		}
		return servlet;
	}
	
	/**
	 * @Method Name  : getMaapingServlet
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param fileName
	 * @return
	 */
	public SimpleServlet getMaapingServlet(final String fileName) {
		SimpleServlet servlet = null;
		String classFullPath = config.getServeltMapping(fileName);
		if("".equals(classFullPath)) {
			return servlet;
		}
		servlet =  getInServlet(classFullPath);
		if(servlet != null) {
			return servlet;
		}
		servlet =  getOutServlet(classFullPath);
		return servlet;
	}
}
