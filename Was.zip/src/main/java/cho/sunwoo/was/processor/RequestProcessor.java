package cho.sunwoo.was.processor;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;

import org.slf4j.LoggerFactory;

import cho.sunwoo.net.http.HttpRequest;
import cho.sunwoo.net.http.HttpResponse;
import cho.sunwoo.net.http.HttpStatusCode;
import cho.sunwoo.was.config.Config;
import cho.sunwoo.was.config.ServerConfig;

/**
 * @FileName  : RequestProcessor.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class RequestProcessor implements Runnable {
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(RequestProcessor.class);
    private Socket connection;
    private String ROOT_PATH;

    public RequestProcessor(Socket connection) {
    	this.connection = connection;
    }

    @Override
    public void run() {
    	try {
    		ServerConfig serverConfig = null;
    		File path = new File("");
    		ROOT_PATH = path.getAbsolutePath();
    		logger.info(ROOT_PATH);
			InputStream input = connection.getInputStream();
			OutputStream output = this.connection.getOutputStream();
			Writer out = new OutputStreamWriter(output);
			
	 		RequestParser parser = new RequestParser(input);
	 		HttpRequest req = parser.Parser();
	 		if(req == null) {
	 			return;
	 		}
	 		String host = req.getHost();
 			serverConfig = Config.getInstance().getServierInfo(host);
 			serverConfig.setRootPath(ROOT_PATH);
 			try {
	 			VirtualHost virtualHost = new VirtualHost(req,output,serverConfig);
	 			virtualHost.exec();
 			} catch (Exception e) {
 				HttpResponse res = new HttpResponse(output);
 				res.setReq(req);
 				res.setConfig(serverConfig);
 				res.sendErrorResponse(HttpStatusCode.NOT_FOUND);
 			}
		} catch (IOException e) {
			logger.error("",e);
		} catch (RuntimeException e) {
			logger.error("",e);
		} catch (Exception e) {
			logger.error("",e);
		} finally {
			try {
				logger.info("connection close");
				connection.close();
			} catch (IOException e) {
				logger.error("",e);
			}
		}
    }
}