package cho.sunwoo.was.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * @FileName  : FileUtils.java
 * @Project     : Was
 * @Date         : 2021. 9. 1.
 * @작성자      : User1
 * @변경이력 :
 * @프로그램 설명 :
 */
public class FileUtils {
	/**
	 * @Method Name  : getFileContent
	 * @작성일   : 2021. 9. 1.
	 * @작성자   : User1
	 * @변경이력  :
	 * @Method 설명 :
	 * @param fileName
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	public static JSONObject getFileContent(String fileName) throws FileNotFoundException, IOException, ParseException  {
		ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        InputStream is = classLoader.getResourceAsStream(fileName);

        JSONParser parser = new JSONParser();
        Object obj = parser.parse(new InputStreamReader(is));
        JSONObject jsonObject = (JSONObject) obj;
        return  (JSONObject) obj;
    }
}
